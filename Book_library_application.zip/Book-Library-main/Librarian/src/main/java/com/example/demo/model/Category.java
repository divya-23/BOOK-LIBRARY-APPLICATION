package com.example.demo.model;

public enum Category {
    NOVEL, THRILER, HISTORY, FANTASY, BIOGRAPHY, CLASSICS, DRAMA;
}
